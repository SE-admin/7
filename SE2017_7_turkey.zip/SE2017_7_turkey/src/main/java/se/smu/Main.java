package se.smu;

public class Main {
	public static Intro introclass;
	
	public static void main(String args[]){
		introclass = new Intro();
		introclass.setVisible(true);
	
	}
	
}
